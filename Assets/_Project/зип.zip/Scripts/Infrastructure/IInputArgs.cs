public interface IInputArgs
{
}