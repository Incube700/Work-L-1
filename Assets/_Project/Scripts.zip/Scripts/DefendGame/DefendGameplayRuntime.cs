using Assets._Project.Scripts.Gameplay.EntitiesCore;
using Assets._Project.Scripts.Gameplay.EntitiesCore.Mono;
using Assets._Project.Scripts.Gameplay.Features.InputFeature;
using Assets._Project.Scripts.Infrastructure.AssetsManagment;
using UnityEngine;

public sealed class DefendGameplayRuntime
{
    private readonly DefendLevelConfig _level;
    private readonly Vector3 _buildingSpawnPoint;
    private readonly LayerMask _groundMask;
    private readonly WalletService _wallet;
    private readonly PlayerProgressService _progress;
    private readonly GameFlowService _flow;
    private readonly DefendGameplayScreenView _screenView;

    private EntitiesLifeContext _life;
    private CollidersRegistryService _collidersRegistry;
    private MonoEntitiesFactory _monoFactory;
    private DefendEntitiesFactory _entitiesFactory;
    private IInputService _input;
    private IPointerService _pointer;
    private ExplosionService _explosions;
    private DefendGameController _controller;

    private bool _isStarted;

    public DefendGameplayRuntime(
        DefendLevelConfig level,
        Vector3 buildingSpawnPoint,
        LayerMask groundMask,
        WalletService wallet,
        PlayerProgressService progress,
        GameFlowService flow,
        DefendGameplayScreenView screenView)
    {
        _level = level;
        _buildingSpawnPoint = buildingSpawnPoint;
        _groundMask = groundMask;
        _wallet = wallet;
        _progress = progress;
        _flow = flow;
        _screenView = screenView;
    }

    public void Start()
    {
        if (_isStarted)
        {
            return;
        }

        ResourcesAssetsLoader loader = new ResourcesAssetsLoader();

        _life = new EntitiesLifeContext();

        _collidersRegistry = new CollidersRegistryService();
        _monoFactory = new MonoEntitiesFactory(loader, _life, _collidersRegistry);
        _monoFactory.Initialize();

        _input = new DesktopInputService();
        _pointer = new DesktopPointerService(Camera.main, _groundMask, _buildingSpawnPoint.y);
        _explosions = new ExplosionService(_collidersRegistry);

        _entitiesFactory = new DefendEntitiesFactory(_life, _monoFactory);

        DefendPhaseService phaseService = new DefendPhaseService();
        WaveProgressService waveProgressService = new WaveProgressService(_level);
        BuildingStateService buildingStateService = new BuildingStateService();
        EnemyService enemyService = new EnemyService();
        DefendResultService resultService = new DefendResultService(_level, _progress, _flow, phaseService);

        Entity building = _entitiesFactory.CreateBuilding(_buildingSpawnPoint, _level);
        buildingStateService.SetBuilding(building);

        EnemySpawner enemySpawner = new EnemySpawner(
            _level,
            _entitiesFactory,
            building,
            enemyService.Add);

        MineFactory mineFactory = new MineFactory(
            _level,
            _entitiesFactory,
            _life,
            _explosions,
            _collidersRegistry);

        MinePlacementService minePlacementService = new MinePlacementService(
            _level,
            _wallet,
            mineFactory);

        DefendInputHandler inputHandler = new DefendInputHandler(
            _input,
            _pointer,
            _explosions,
            minePlacementService,
            _level);

        DefendStateMachineFactory stateMachineFactory = new DefendStateMachineFactory(
            phaseService,
            waveProgressService,
            buildingStateService,
            resultService,
            enemySpawner,
            enemyService,
            _level.RestDurationSeconds);

        DefendStateMachine stateMachine = stateMachineFactory.Create();

        _controller = new DefendGameController(
            _life,
            phaseService,
            waveProgressService,
            buildingStateService,
            resultService,
            enemyService,
            inputHandler,
            stateMachine);

        _controller.Start();

        if (_screenView != null)
        {
            // HUD подключим следующим шагом.
        }

        _isStarted = true;
    }

    public void Update(float deltaTime)
    {
        if (_isStarted == false)
        {
            return;
        }

        _input.Tick();
        _controller.Update(deltaTime);
        _life.Update(deltaTime);
    }

    public void Dispose()
    {
        if (_isStarted == false)
        {
            return;
        }

        _controller.Dispose();
        _life.Dispose();
        _monoFactory.Dispose();

        _controller = null;
        _life = null;
        _collidersRegistry = null;
        _monoFactory = null;
        _entitiesFactory = null;
        _input = null;
        _pointer = null;
        _explosions = null;

        _isStarted = false;
    }
}